// declaration
class HelloWorldComponent extends HTMLElement {
  constructor() {
    super();
    console.log("Hello Web Component !");
  }
}
// define
customElements.define("uc-helloworld", HelloWorldComponent);
