const express = require("express");
const path = require("path");
let courses = require("./models/courses.model");
var cors = require("cors");

let app = express();
app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());
app.use(cors());
// app.get("/", (req, res) => {
//   //   res.send("Hello Express !");
//   //   res.json({ name: "Microsoft", location: "Hyderabad" });
//   //   res.sendFile("Index.html", { root: __dirname });
//   res.sendFile("Courses.html", { root: __dirname });
// });

app.get("/courses", (req, res) => {
  // create array of 5 courses
  // course -> id, title, price, rating, likes, imageUrl
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  // get the data
  let courseToBeAdded = req.body;
  courses = [...courses, courseToBeAdded]; // push !
  res.json({ msg: "success" });
});
app.delete("/courses/:id", (req, res) => {
  let theCourseId = +req.params.id;
  //   console.log("Deleting..", theCourseId);
  // functional programming -> (immutable)
  courses = courses.filter((course) => course.id != theCourseId);
  console.log(courses);

  res.json({ msg: "success" });
});
app.listen(5000, () => console.log("Server running at 5000 !"));
