export var Add = (x, y) => x + y;

export class Point {
  x = 100;
  y = 100;
}

const PI = 3.14;
