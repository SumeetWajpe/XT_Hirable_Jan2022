function GetPosts(callback) {
  // make the AJAX call
  //1. Instanciate XMLHttpRequest object
  //2. Configure XMLHttpReq instance with open(VERB,URL)
  //3. Make the async call
  //4. register onreadystatechange | readyState -> 0,1,2,3,4

  var xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/post");
  xmlHttpReq.send(); // places the async call
  xmlHttpReq.onreadystatechange = function () {
    if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
      callback(null, xmlHttpReq.responseText);
    } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status != 200) {
      callback("Something went wrong !" + xmlHttpReq.status, null);
    }
  };
}
