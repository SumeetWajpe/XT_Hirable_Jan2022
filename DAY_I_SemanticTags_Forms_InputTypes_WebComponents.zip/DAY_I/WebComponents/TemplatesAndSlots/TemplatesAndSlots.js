class TemplatesAndSlots extends HTMLElement {
  constructor() {
    super();
    const template = document.querySelector(
      "#element-details-template"
    ).content;
    this.attachShadow({ mode: "open" }).appendChild(template.cloneNode(true));
  }
}

customElements.define("element-details", TemplatesAndSlots);
