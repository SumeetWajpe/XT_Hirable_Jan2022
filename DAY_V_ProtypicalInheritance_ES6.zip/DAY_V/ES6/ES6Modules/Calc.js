// import { Add as Addition } from "./Math.js";
// console.log("Addition is : " + Addition(20, 30));

import * as MathModule from "./Math.js";
console.log("Addition is : " + MathModule.Add(20, 30));
