import { Add, Point } from "./module";

console.log("The Addition is : " + Add(20, 50));

var point = new Point();
point.x = 200;
point.y = 200;
